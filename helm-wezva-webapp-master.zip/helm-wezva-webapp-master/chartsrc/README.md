
1. Create sample.conf in the chart at the same dir level as values.yaml
2. Update values.yaml with correct Image name
3. Run the following from the chart dir
  $ helm install <chartnaame> --dry-run .
  $ helm install <chartnaame> .
